import { Navigate } from "react-router-dom";
import { AuthLayout } from "../features/auth/components/auth-layout";
import { SignupForm } from "../features/auth/components/signup-form";
import { useAuthContext } from "../app/providers/useAuthContext";

export default function SignupPage() {
    const { isAuthenticated } = useAuthContext();

    if (isAuthenticated) {
        return <Navigate to="/submission" replace />;
    }
    return (
        <AuthLayout>
            <SignupForm />
        </AuthLayout>
    );
}
