import { FileText, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { useNavigate } from "react-router-dom";
import { useAuthContext } from "../app/providers/useAuthContext";

export default function LandingPage() {
    const navigate = useNavigate();
    const { isAuthenticated } = useAuthContext();

    const handleLoginNav = () => {
        if (isAuthenticated) {
            navigate("/submission");
        } else {
            navigate("/login");
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 flex flex-col font-sans relative overflow-hidden">
            {/* Background decoration */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[80%] w-[600px] h-[600px] bg-[#74AF56]/15 rounded-full border-[20px] border-[#74AF56]/20 blur-[2px] -z-10" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[80%] w-[800px] h-[800px] bg-transparent rounded-full border-[15px] border-[#74AF56]/10 blur-[2px] -z-10" />
            <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-[#74AF56]/20 to-transparent -z-20" />

            {/* Header */}
            <header className="flex justify-between items-center px-8 py-4 border-b border-gray-200 bg-white shadow-sm z-10 w-full">
                <img src="/keystone_logo.webp" alt="Keystone Symposia Logo" className="h-10" />
                <Avatar
                    onClick={handleLoginNav}
                    className="cursor-pointer hover:ring-2 hover:ring-[#74AF56] transition-all bg-gray-100"
                >
                    <AvatarImage src="" />
                    <AvatarFallback>
                        <User className="h-5 w-5 text-gray-600" />
                    </AvatarFallback>
                </Avatar>
            </header>

            {/* Main Content */}
            <main className="flex-1 flex flex-col items-center justify-start pt-24 px-4 z-10">
                <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 text-center">
                    Propose a Scientific Conference
                </h1>
                <p className="text-gray-600 max-w-2xl text-center text-lg mb-8">
                    Share your vision for a groundbreaking scientific meeting. Our expert panel reviews proposals and helps bring the most impactful conferences to life.
                </p>
                <Button
                    onClick={handleLoginNav}
                    className="bg-[#74AF56] hover:bg-[#5a8b42] text-white px-8 py-6 rounded-md text-lg shadow-lg hover:shadow-xl transition-all"
                >
                    Submit Concept
                </Button>

                {/* Info Card */}
                <Card className="mt-20 w-full max-w-5xl bg-white p-10 rounded-2xl shadow-xl z-10 mx-auto">
                    <h2 className="text-3xl font-bold text-center mb-4">What is a Conference Concept?</h2>
                    <p className="text-center text-gray-500 max-w-3xl mx-auto mb-12">
                        A conference concept is a proposal for a focused scientific meeting that brings together researchers to advance a specific field. Your submission should articulate the scientific need, timing rationale, and potential impact of the proposed conference.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        <FeatureItem
                            icon={<FileText className="h-6 w-6 text-[#74AF56]" />}
                            title="Clear Focus"
                            description="Define the scientific topic and why it needs dedicated attention now."
                        />
                        <FeatureItem
                            icon={<FileText className="h-6 w-6 text-[#74AF56]" />}
                            title="Community Impact"
                            description="Explain how this conference advances the field and benefits."
                        />
                        <FeatureItem
                            icon={<FileText className="h-6 w-6 text-[#74AF56]" />}
                            title="Timely Relevance"
                            description="Demonstrate why this is the right moment for this conference."
                        />
                        <FeatureItem
                            icon={<FileText className="h-6 w-6 text-[#74AF56]" />}
                            title="Feasibility & Clarity"
                            description="Show the concept is well-structured and achievable."
                        />
                    </div>
                </Card>
            </main>
        </div>
    );
}

function FeatureItem({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
    return (
        <div className="flex flex-col items-start">
            <div className="bg-[#74AF56]/15 p-3 rounded-xl mb-4">
                {icon}
            </div>
            <h3 className="text-lg font-bold mb-2 text-gray-800">{title}</h3>
            <p className="text-gray-500 text-sm">{description}</p>
        </div>
    );
}
