import { useState } from "react";
import { PageShell } from "../components/layout/PageShell";
import { DynamicForm } from "../features/form-submission/components/dynamic-form";
import { useFormSubmission } from "../features/form-submission/hooks/use-form-submission";
import { useAuthContext } from "../app/providers/useAuthContext";
import { Loader2, ChevronLeft, FileText, User, Microscope } from "lucide-react";
import { Button } from "../components/ui/button";
import { cn } from "../lib/utils";

export default function SubmissionPage() {
    const { config, isLoading, isSubmitting, error, submitForm } = useFormSubmission();
    const { user } = useAuthContext();
    const [activeTab, setActiveTab] = useState<"single" | "bulk">("single");
    const [activeSection, setActiveSection] = useState("");

    const getSidebarIcon = (title: string) => {
        const t = title.toLowerCase();
        if (t.includes("overview")) return <FileText className="h-4 w-4" />;
        if (t.includes("organizer")) return <User className="h-4 w-4" />;
        if (t.includes("rationale")) return <Microscope className="h-4 w-4" />;
        return <FileText className="h-4 w-4" />;
    };

    const scrollToSection = (sectionId: string) => {
        setActiveSection(sectionId);
        const element = document.getElementById(sectionId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="flex flex-col items-center gap-4">
                    <Loader2 className="h-10 w-10 text-purple-600 animate-spin" />
                    <p className="text-gray-500 font-medium">Loading form configuration...</p>
                </div>
            </div>
        );
    }

    if (error || !config) {
        return (
            <PageShell className="flex items-center justify-center">
                <div className="text-center p-8 bg-white rounded-2xl shadow-xl max-w-md">
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">Error</h2>
                    <p className="text-gray-600 mb-6">{error || "Something went wrong."}</p>
                    <Button onClick={() => window.location.reload()} className="bg-purple-600">
                        Retry
                    </Button>
                </div>
            </PageShell>
        );
    }

    const sections = config.map((section) => ({
        id: section.sectionTitle.toLowerCase().replace(/\s+/g, '-'),
        label: section.sectionTitle,
        icon: getSidebarIcon(section.sectionTitle)
    }));

    // Set initial active section once config is loaded
    if (!activeSection && sections.length > 0) {
        setActiveSection(sections[0].id);
    }

    const canBulk = user?.role === "keystone_member";

    return (
        <PageShell className="relative pb-24">
            {/* Background circles effect */}
            <div className="absolute top-0 right-0 w-[600px] h-[600px] -z-10 opacity-30 pointer-events-none overflow-hidden">
                <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] rounded-full border border-gray-200" />
                <div className="absolute top-[-200px] right-[-200px] w-[700px] h-[700px] rounded-full border border-gray-100" />
                <div className="absolute top-[-300px] right-[-300px] w-[900px] h-[900px] rounded-full border border-gray-50" />
            </div>

            <div className="max-w-[1240px] mx-auto px-8 pt-10">
                {/* Title and Back Link */}
                <div className="mb-8">
                    <button className="flex items-center text-gray-500 hover:text-gray-700 mb-4 transition-colors">
                        <ChevronLeft className="h-5 w-5 mr-1" />
                        <span className="text-sm font-medium">Submit Concept</span>
                    </button>
                    <div className="space-y-1">
                        <h1 className="text-2xl font-extrabold text-gray-900 tracking-tight">Submit Concept</h1>
                        <p className="text-gray-500 text-sm font-medium">Provide details about the proposed concept.</p>
                    </div>
                </div>

                {/* Tabs - only show for keystone members */}
                {canBulk && (
                    <div className="flex bg-gray-100/80 p-1 rounded-lg w-fit mb-10 shadow-sm border border-gray-200/50">
                        <button
                            onClick={() => setActiveTab("single")}
                            className={cn(
                                "px-6 py-2 text-xs font-semibold rounded-md transition-all",
                                activeTab === "single" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"
                            )}
                        >
                            Single Concept
                        </button>
                        <button
                            onClick={() => setActiveTab("bulk")}
                            className={cn(
                                "px-6 py-2 text-xs font-semibold rounded-md transition-all",
                                activeTab === "bulk" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"
                            )}
                        >
                            Bulk Concept
                        </button>
                    </div>
                )}

                <div className="grid grid-cols-12 gap-8 items-start pb-20">
                    {/* Sidebar */}
                    <div className="col-span-3 bg-white rounded-[32px] shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 p-8 sticky top-28 min-h-[600px]">
                        <h2 className="text-[20px] font-bold text-[#1E293B] mb-4 px-2 tracking-tight">Sections</h2>
                        <div className="h-px bg-gray-100 mb-8 mx-2" />
                        <nav className="space-y-4">
                            {sections.map((section) => (
                                <button
                                    key={section.id}
                                    onClick={() => scrollToSection(section.id)}
                                    className={cn(
                                        "flex items-center w-full px-6 py-4 rounded-xl transition-all font-semibold text-left group",
                                        activeSection === section.id
                                            ? "bg-[#F8FAFC] text-[#1E293B] border border-[#E2E8F0] border-l-[4px] border-l-[#4121B6]"
                                            : "text-[#334155] hover:bg-gray-50"
                                    )}
                                >
                                    <div className="w-2.5 h-2.5 rounded-full bg-[#1E293B] mr-4 shrink-0" />
                                    <span className="text-[15px] tracking-tight">{section.label}</span>
                                </button>
                            ))}
                        </nav>
                    </div>

                    {/* Form Content */}
                    <div className="col-span-9 bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mb-12 min-h-[600px]">
                        <div className="p-8">
                            <DynamicForm
                                config={config}
                                onSubmit={submitForm}
                                isSubmitting={isSubmitting}
                                hideSubmitButton={true}
                                id="concept-form"
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Footer Actions */}
            <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-8 py-4 z-40 flex justify-end gap-4 shadow-[0_-4px_12px_rgba(0,0,0,0.05)]">
                <Button variant="ghost" className="px-8 font-bold text-gray-500 hover:text-gray-700">Cancel</Button>
                <Button
                    form="concept-form"
                    type="submit"
                    className="bg-[#4121B6] hover:bg-[#351996] text-white px-10 font-bold rounded-lg h-11 transition-all shadow-md shadow-purple-200"
                    disabled={isSubmitting}
                >
                    {isSubmitting ? "Submitting..." : "Submit"}
                </Button>
            </footer>
        </PageShell>
    );
}
