import { Navigate } from "react-router-dom";
import { AuthLayout } from "../features/auth/components/auth-layout";
import { LoginForm } from "../features/auth/components/login-form";
import { useAuthContext } from "../app/providers/useAuthContext";

export default function LoginPage() {
    const { isAuthenticated } = useAuthContext();

    if (isAuthenticated) {
        return <Navigate to="/submission" replace />;
    }
    return (
        <AuthLayout>
            <LoginForm />
        </AuthLayout>
    );
}
