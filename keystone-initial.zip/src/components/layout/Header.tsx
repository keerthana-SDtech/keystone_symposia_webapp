import { useNavigate } from "react-router-dom";
import { Avatar, AvatarFallback } from "../ui/avatar";
import { useAuthContext } from "../../app/providers/useAuthContext";
import { User, LogOut, Settings, HelpCircle } from "lucide-react";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "../ui/dropdown-menu";

export const Header = () => {
    const { user, logout } = useAuthContext();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate("/login");
    };

    return (
        <header className="flex justify-between items-center px-12 py-3 border-b border-gray-100 bg-white sticky top-0 z-50 h-[72px]">
            <div className="flex items-center cursor-pointer" onClick={() => navigate("/")}>
                <img src="/keystone_logo.webp" alt="Keystone Symposia" className="h-[34px] object-contain" />
            </div>

            <div className="flex items-center">
                {user ? (
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Avatar className="h-10 w-10 border border-gray-100 cursor-pointer bg-gray-50/50 transition-all hover:ring-2 hover:ring-purple-100">
                                <AvatarFallback className="bg-transparent">
                                    <User className="h-5 w-5 text-gray-400" />
                                </AvatarFallback>
                            </Avatar>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56 mt-2 rounded-xl border-gray-100 shadow-xl">
                            <DropdownMenuLabel className="font-normal">
                                <div className="flex flex-col space-y-1">
                                    <p className="text-sm font-bold leading-none text-gray-900">{user.name}</p>
                                    <p className="text-xs leading-none text-gray-500 italic">{user.role.replace('_', ' ')}</p>
                                    <p className="text-xs leading-none text-gray-400 truncate">{user.email}</p>
                                </div>
                            </DropdownMenuLabel>
                            <DropdownMenuSeparator className="bg-gray-50" />
                            <DropdownMenuItem className="cursor-pointer py-2.5 text-gray-600 focus:bg-purple-50 focus:text-purple-700 rounded-lg mx-1">
                                <Settings className="mr-2 h-4 w-4" />
                                <span>Account Settings</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer py-2.5 text-gray-600 focus:bg-purple-50 focus:text-purple-700 rounded-lg mx-1">
                                <HelpCircle className="mr-2 h-4 w-4" />
                                <span>Help & Support</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator className="bg-gray-50" />
                            <DropdownMenuItem
                                onClick={handleLogout}
                                className="cursor-pointer py-2.5 text-red-600 focus:bg-red-50 focus:text-red-700 rounded-lg mx-1"
                            >
                                <LogOut className="mr-2 h-4 w-4" />
                                <span>Log out</span>
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                ) : (
                    <Avatar
                        className="h-10 w-10 border border-gray-100 cursor-pointer bg-gray-50/50 hover:bg-gray-100"
                        onClick={() => navigate("/login")}
                    >
                        <AvatarFallback className="bg-transparent">
                            <User className="h-5 w-5 text-gray-400" />
                        </AvatarFallback>
                    </Avatar>
                )}
            </div>
        </header>
    );
};
