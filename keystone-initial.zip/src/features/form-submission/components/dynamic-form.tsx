import React, { useMemo } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { generateZodSchema } from "../schemas";
import type { FormConfig, FormField } from "../../form-builder/types";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Textarea } from "../../../components/ui/textarea";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue
} from "../../../components/ui/select";
import { FileText, Users, FlaskConical, Calendar } from "lucide-react";

interface DynamicFormProps {
    config: FormConfig;
    onSubmit: (data: any) => void;
    isSubmitting?: boolean;
    hideSubmitButton?: boolean;
    id?: string;
}

const getSectionIcon = (title: string) => {
    const t = title.toLowerCase();
    if (t.includes("overview")) return <FileText className="h-5 w-5 text-gray-400" />;
    if (t.includes("organizer")) return <Calendar className="h-5 w-5 text-gray-400" />;
    if (t.includes("rationale")) return <FlaskConical className="h-5 w-5 text-gray-400" />;
    return <FileText className="h-5 w-5 text-gray-400" />;
};

const getAutoCompleteValue = (field: FormField, formId?: string) => {
    const name = field.name.toLowerCase();
    const type = field.type;
    const format = field.format || (field.validation as any)?.format;

    // type="password" + login form → "current-password"
    // type="password" + signup form → "new-password"
    if (type === 'password' || name.includes('password')) {
        const isLogin = formId?.toLowerCase().includes('login');
        const isSignup = formId?.toLowerCase().includes('signup') || formId?.toLowerCase().includes('register');

        if (isLogin) return "current-password";
        if (isSignup) return "new-password";
        return name.includes('new') ? 'new-password' : 'current-password';
    }

    // format="email" or name includes "email" → "email"
    if (format === 'email' || name.includes('email')) {
        return "email";
    }

    // name includes "first" → "given-name"
    if (name.includes('first')) {
        return "given-name";
    }

    // name includes "last" → "family-name"
    if (name.includes('last')) {
        return "family-name";
    }

    return "off";
};

export const DynamicForm: React.FC<DynamicFormProps> = ({ config, onSubmit, isSubmitting, hideSubmitButton, id }) => {
    const schema = useMemo(() => generateZodSchema(config), [config]);

    const { register, handleSubmit, control, formState: { errors } } = useForm({
        resolver: zodResolver(schema),
    });

    const renderField = (field: FormField) => {
        const error = errors[field.name];

        return (
            <div key={field.name} className={`space-y-2 ${field.layout === 'half' ? 'col-span-1' : 'col-span-full'}`}>
                <Label htmlFor={field.name} className="text-[13px] font-semibold text-gray-700">
                    {field.label}
                    {field.required && <span className="text-red-500 ml-1 font-bold">*</span>}
                </Label>

                {(field.type === 'text' || field.type === 'password' || field.type === 'email') && (
                    <Input
                        id={field.name}
                        type={field.type}
                        autoComplete={getAutoCompleteValue(field, id)}
                        placeholder={field.placeholder}
                        {...register(field.name)}
                        className={`h-11 bg-gray-50/30 border-gray-200 focus:bg-white transition-all text-gray-600 ${error ? "border-red-500 bg-red-50/50" : "hover:border-gray-300"}`}
                    />
                )}

                {field.type === 'textarea' && (
                    <Textarea
                        id={field.name}
                        placeholder={field.placeholder}
                        {...register(field.name)}
                        className={`bg-gray-50/30 border-gray-200 focus:bg-white transition-all text-gray-600 ${error ? "border-red-500 bg-red-50/50" : "hover:border-gray-300"}`}
                        rows={4}
                    />
                )}

                {field.type === 'select' && field.options && (
                    <Controller
                        name={field.name}
                        control={control}
                        render={({ field: { onChange, value } }) => (
                            <Select onValueChange={onChange} value={(value as string) || ""}>
                                <SelectTrigger className={`h-11 bg-gray-50/30 border-gray-200 focus:bg-white transition-all text-gray-600 ${error ? "border-red-500 bg-red-50/50" : "hover:border-gray-300"}`}>
                                    <SelectValue placeholder={(field.placeholder as string) || "Select an option"} />
                                </SelectTrigger>
                                <SelectContent>
                                    {field.options?.map((opt) => (
                                        <SelectItem key={opt.id} value={opt.label}>
                                            {opt.label}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        )}
                    />
                )}

                {error && (
                    <p className="text-[11px] text-red-500 font-semibold px-1">
                        {error.message as string}
                    </p>
                )}
            </div>
        );
    };

    const renderSection = (section: any, isSubsection = false) => (
        <div key={section.sectionTitle} className={isSubsection ? "mt-8 p-6 bg-slate-50/50 rounded-2xl border border-gray-100 shadow-sm" : "space-y-8"}>
            <div className="flex items-center gap-3 mb-6">
                {!isSubsection ? (
                    <div className="flex items-center gap-3">
                        {getSectionIcon(section.sectionTitle)}
                        <h3 className="text-[18px] font-bold text-gray-900 tracking-tight">
                            {section.sectionTitle}
                        </h3>
                    </div>
                ) : (
                    <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <h4 className="text-[12px] font-bold text-gray-700 uppercase tracking-wider">
                            {section.sectionTitle}
                        </h4>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-2 gap-x-6 gap-y-6">
                {section.fields?.map(renderField)}
            </div>

            {section.subsections?.map((sub: any) => renderSection(sub, true))}
        </div>
    );

    return (
        <form id={id} onSubmit={handleSubmit(onSubmit)} className="space-y-16">
            {config.map((section) => (
                <div
                    key={section.sectionTitle}
                    id={section.sectionTitle.toLowerCase().replace(/\s+/g, '-')}
                    className="pb-12 border-b border-gray-100 last:border-0 last:pb-0 scroll-mt-24"
                >
                    {renderSection(section)}
                </div>
            ))}

            {!hideSubmitButton && (
                <div className="flex justify-end pt-6">
                    <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="bg-[#4121B6] hover:bg-[#351996] text-white px-10 py-6 text-lg font-bold rounded-xl shadow-lg transition-all"
                    >
                        {isSubmitting ? "Submitting..." : "Submit Proposal"}
                    </Button>
                </div>
            )}
        </form>
    );
};
