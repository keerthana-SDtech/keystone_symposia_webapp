import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link } from "react-router-dom";
import { signupSchema } from "../schemas";
import type { SignupFormValues } from "../schemas";
import { useAuth } from "../hooks/use-auth";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Card, CardContent } from "../../../components/ui/card";

export const SignupForm = () => {
    const { signup, isLoading, error } = useAuth();

    const form = useForm<SignupFormValues>({
        resolver: zodResolver(signupSchema),
        defaultValues: {
            name: "",
            email: "",
            password: "",
            confirmPassword: "",
        },
    });

    const onSubmit = (values: SignupFormValues) => {
        signup(values);
    };

    return (
        <Card className="border-none shadow-2xl bg-white rounded-2xl overflow-hidden font-sans">
            <CardContent className="pt-10 pb-12 px-10">
                <div className="flex flex-col items-center mb-8">
                    <img
                        src="/keystone_logo.webp"
                        alt="Keystone Symposia"
                        className="h-12 mb-6 object-contain"
                    />
                    <h2 className="text-2xl font-bold text-[#333] mb-2">Create Account</h2>
                    <p className="text-gray-500 text-center text-sm">
                        Join Keystone Symposia to submit your scientific concepts
                    </p>
                </div>

                {error && (
                    <div className="mb-6 p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm text-center font-medium">
                        {error}
                    </div>
                )}

                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                    <div className="space-y-2">
                        <Label htmlFor="name">
                            Full Name<span className="text-red-500 ml-1">*</span>
                        </Label>
                        <Input
                            id="name"
                            autoComplete="name"
                            placeholder="Enter your name"
                            {...form.register("name")}
                            className={`h-11 border-gray-200 focus:ring-green-500 focus:border-green-500 ${form.formState.errors.name ? 'border-red-500 shadow-sm shadow-red-100' : ''}`}
                        />
                        {form.formState.errors.name && (
                            <p className="text-[11px] text-red-500 font-medium px-1 mt-1">{form.formState.errors.name.message}</p>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="email">
                            Email<span className="text-red-500 ml-1">*</span>
                        </Label>
                        <Input
                            id="email"
                            type="email"
                            autoComplete="email"
                            placeholder="Enter email"
                            {...form.register("email")}
                            className={`h-11 border-gray-200 focus:ring-green-500 focus:border-green-500 ${form.formState.errors.email ? 'border-red-500 shadow-sm shadow-red-100' : ''}`}
                        />
                        {form.formState.errors.email && (
                            <p className="text-[11px] text-red-500 font-medium px-1 mt-1">{form.formState.errors.email.message}</p>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="password">
                            Password<span className="text-red-500 ml-1">*</span>
                        </Label>
                        <Input
                            id="password"
                            type="password"
                            autoComplete="new-password"
                            placeholder="Create password"
                            {...form.register("password")}
                            className={`h-11 border-gray-200 focus:ring-green-500 focus:border-green-500 ${form.formState.errors.password ? 'border-red-500 shadow-sm shadow-red-100' : ''}`}
                        />
                        {form.formState.errors.password && (
                            <p className="text-[11px] text-red-500 font-medium px-1 mt-1">{form.formState.errors.password.message}</p>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="confirmPassword">
                            Confirm Password<span className="text-red-500 ml-1">*</span>
                        </Label>
                        <Input
                            id="confirmPassword"
                            type="password"
                            autoComplete="new-password"
                            placeholder="Repeat password"
                            {...form.register("confirmPassword")}
                            className={`h-11 border-gray-200 focus:ring-green-500 focus:border-green-500 ${form.formState.errors.confirmPassword ? 'border-red-500 shadow-sm shadow-red-100' : ''}`}
                        />
                        {form.formState.errors.confirmPassword && (
                            <p className="text-[11px] text-red-500 font-medium px-1 mt-1">{form.formState.errors.confirmPassword.message}</p>
                        )}
                    </div>

                    <Button
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-[#74AF56] hover:bg-[#5a8b42] text-white h-11 text-base font-bold rounded-lg shadow-sm hover:shadow-md transition-all mt-4"
                    >
                        {isLoading ? "Creating Account..." : "Sign Up"}
                    </Button>

                    <p className="text-center text-sm text-gray-600 mt-6">
                        Already have an account?{" "}
                        <Link to="/login" className="text-[#74AF56] font-bold hover:underline">
                            Login
                        </Link>
                    </p>
                </form>
            </CardContent>
        </Card>
    );
};
