import React from "react";

export const AuthLayout = ({ children }: { children: React.ReactNode }) => {
    return (
        <div className="min-h-screen bg-[#2D1B69] flex items-center justify-center relative overflow-hidden font-sans">
            {/* Decorative Circles */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <div className="w-[400px] h-[400px] rounded-full border border-white/10" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-white/10" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full border border-white/10" />
            </div>

            {/* Floating Blobs (Blur effects for the landing page vibe) */}
            <div className="absolute top-[20%] left-[20%] w-32 h-32 bg-purple-500/20 rounded-full blur-3xl" />
            <div className="absolute bottom-[20%] right-[20%] w-48 h-48 bg-purple-400/10 rounded-full blur-3xl" />

            {/* Centered Card Content */}
            <div className="relative z-10 w-full max-w-md px-4">
                {children}
            </div>
        </div>
    );
};
