import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link } from "react-router-dom";
import { loginSchema } from "../schemas";
import type { LoginFormValues } from "../schemas";
import { useAuth } from "../hooks/use-auth";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Checkbox } from "../../../components/ui/checkbox";
import { Label } from "../../../components/ui/label";
import { Card, CardContent } from "../../../components/ui/card";

export const LoginForm = () => {
    const { login, isLoading, error } = useAuth();

    const form = useForm<LoginFormValues>({
        resolver: zodResolver(loginSchema),
        defaultValues: {
            email: "",
            password: "",
            rememberMe: false,
        },
    });

    const onSubmit = (values: LoginFormValues) => {
        login(values);
    };

    return (
        <Card className="border-none shadow-2xl bg-white rounded-2xl overflow-hidden">
            <CardContent className="pt-10 pb-12 px-10">
                <div className="flex flex-col items-center mb-8">
                    <img
                        src="/keystone_logo.webp"
                        alt="Keystone Symposia"
                        className="h-12 mb-6 object-contain"
                    />
                    <h2 className="text-2xl font-bold text-[#333] mb-2">Welcome Back</h2>
                    <p className="text-gray-500 text-center text-sm">
                        Enter your credentials to login and submit concept
                    </p>
                </div>

                {error && (
                    <div className="mb-6 p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm">
                        {error}
                    </div>
                )}

                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="email">
                            Email<span className="text-red-500 ml-1">*</span>
                        </Label>
                        <Input
                            id="email"
                            type="email"
                            autoComplete="email"
                            placeholder="Enter email"
                            {...form.register("email")}
                            className={`h-12 border-gray-200 focus:ring-green-500 focus:border-green-500 ${form.formState.errors.email ? 'border-red-500' : ''}`}
                        />
                        {form.formState.errors.email && (
                            <p className="text-xs text-red-500">{form.formState.errors.email.message}</p>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="password">
                            Password<span className="text-red-500 ml-1">*</span>
                        </Label>
                        <Input
                            id="password"
                            type="password"
                            autoComplete="current-password"
                            placeholder="Enter password"
                            {...form.register("password")}
                            className={`h-12 border-gray-200 focus:ring-green-500 focus:border-green-500 ${form.formState.errors.password ? 'border-red-500' : ''}`}
                        />
                        {form.formState.errors.password && (
                            <p className="text-xs text-red-500">{form.formState.errors.password.message}</p>
                        )}
                    </div>

                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                            <Checkbox
                                id="rememberMe"
                                onCheckedChange={(checked) => form.setValue("rememberMe", checked as boolean)}
                            />
                            <Label htmlFor="rememberMe" className="text-sm text-gray-600 cursor-pointer">
                                Remember Me
                            </Label>
                        </div>
                        <Link to="/forgot-password" className="text-sm font-medium text-[#74AF56] hover:underline">
                            Forget Password?
                        </Link>
                    </div>

                    <Button
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-[#74AF56] hover:bg-[#5a8b42] text-white h-12 text-base font-semibold rounded-lg shadow-md hover:shadow-lg transition-all"
                    >
                        {isLoading ? "Logging in..." : "Login"}
                    </Button>

                    <p className="text-center text-sm text-gray-600 mt-6">
                        Don't have an account?{" "}
                        <Link to="/signup" className="text-[#74AF56] font-bold hover:underline">
                            Sign Up
                        </Link>
                    </p>
                </form>
            </CardContent>
        </Card>
    );
};
